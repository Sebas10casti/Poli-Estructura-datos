
public class Semana3Ejercicio2CMain {

	public static void main(String[] args) {
		//Arreglo Ejemplo
		int[]arreglo= {11,9,4,3,5,2,6,7,8,10};
		//Instanciar el objeto
		semana3Ejercicio2C o = new semana3Ejercicio2C();
		//LLamar metodo
		o.ordenar_numeros(arreglo);
		//imprimir arreglo
		for (int i=0;i<arreglo.length;i++) {
				System.out.println((arreglo[i]));
		}
	}
}
