
public class Semana3Ejercicio3 {
	
	private void garantizarCapacidad(int nuevaCantidadDeElementos) {
		//Declarar Variable con el valor a aumentar
		int aumentarEspacios = 20;
		//Modificar la primera condicion del ejemplo ya que no hace nada
		if(nuevaCantidadDeElementos > arreglo.length){
			//si la nueva cantidad de elementos es menor que la suma del arreglo más la cantidad declarada 
			//de la capacidad del arreglo, aumentar la cantidad de espacios declarados en la varible
			if(nuevaCantidadDeElementos < arreglo.length + aumentarEspacios) {
				nuevaCantidadDeElementos = arreglo.length +  aumentarEspacios;
			}
			//Crear un nuevo arreglo donde quepa la nueva cantidad de elementos
			Object[] nuevoArreglo = new Object[nuevaCantidadDeElementos];
			
			//Pienso que no deberia ser "tamanho" si no arreglo.length"
			//ya que vamos a asignar los valores del antiguo arreglo al nuevo.
			for(int i = 0; i < tamanho; i++) {
				nuevoArreglo[i] = arreglo[i];
			}
			//Desechar el viejo arreglo, asignándole el nuevo:
			arreglo = nuevoArreglo;
		}
	}
	
}
