import java.util.Scanner;
public class semana3Ejercicio1 {
    //Deje todo en la misma clase,el main y el metodo  
    public static void main(String[] args) {
    	semana3Ejercicio1.arreglo();
    }
    //cree metodo Arreglo para que realizara el ejercicio propuesto
    
    static int [] arreglo(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el tamaño del arreglo ");
        int A = sc.nextInt();
        //Inicialice una variable de tipo entera el cual va a ser el tamaño del arreglo y lo va a dar el usuario
        int arreglo []= new int [A];
        //cree el arreglo con el tamaño "A" que da el usuario
        int i; int j;
        // cree dos variables tipo entero que van a ser usadas para recorrer el arreglo
        int contar []= new int [10];
        //cree otro arreglo de tamaño 10 para que vea de los numeros escritos por el usuario cuantos se repiten
        int ocurrencia;
        
        System.out.println("Ingrese los "+A+" numeros");
        for (i = 0; i< arreglo.length; i++){
            arreglo[i] = sc.nextInt();
        }
        // ciclo for para rellenar el arreglo
        for(j = 0; j < arreglo.length; j++){
            contar[arreglo[j]]+=1;
        }
        //otro ciclo para las ocurrencias
        
        
        for(ocurrencia = 0; ocurrencia < contar.length; ocurrencia++){
            System.out.println("La ocurrencia de n en la posición "+ocurrencia+" es: "+contar[ocurrencia]+" veces ");
        }
        //y por ultimo el ciclo que va a mostrar en pantalla el arreglo, con los numeros dados y el numero de ocurrencias
        return null;
    }
}
