import java.util.Scanner;
import javax.swing.JOptionPane;

public class semana3Ejercicio2A {

	public static void main(String[] args) {
		int arreglo[] , nElementos;
		Scanner entrada = new Scanner(System.in);
		
		nElementos = Integer.parseInt(("Digite la cantidad de elementos del arreglo"));
		arreglo = new int [nElementos]; 
		
		for (int i=0;i<nElementos;i++){
			System.out.println((i+1)+". Digite un numero: ");
			arreglo[i] = entrada.nextInt();
		}
		
		int aux;
		for (int i=0;i<(nElementos-1);i++){
			if (arreglo[i]>arreglo[i+1]) {
				aux = arreglo[i];
				arreglo[i]=arreglo[i+1];
				arreglo[i+1]=aux;

			}
		}
	System.out.print("\nArreglo ordenado en forma creciente: ");
	for(int i=0;i<nElementos;i++){
		System.out.println(arreglo[i]+ " - ");
	}
	System.out.println("\nArreglo ordenado en forma decreciente");
	for(int i=(nElementos-1);i>=0;i--){
		System.out.print(arreglo[i]+" - ");
	}
	System.out.print("");
	}
}
