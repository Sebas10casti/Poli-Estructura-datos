
public class semana3Ejercicio2C {

	public void ordenar_numeros (int[] array) {
		//Almacenar el valor que recorremos para acomodarlo
		int aux;
		//Declarar un Booleano para terminar el ciclo cuando este acabe de ordenar
		boolean cambios=false;
		//Evitar que se ejecute el algoritmo si el arreglo es menor o igual a 1
		if(array.length > 1) {
			//Iniciar ciclo de ordenamiento
			while(true) {
				//La variable se cambia a False en cada vuelta hasta terminar el ciclo for, asi sabemos cuando termino
				cambios=false;
				
				//Iniciar el ciclo de ordenamiento burbuja
				for(int i=1;i<array.length;i++) {
					//Validar si el numero recorrido es menor a su anterior posicion y ordenarlo
					//Ejemplo 2 < 3 
					if (array[i] < array[i-1]) {
						//si es menor lo almacenamos ejemplo 2
						aux = array[i];
						//Reemplazamos la posicion donde estaba el 2 con el 3
						array[i]= array[i-1];
						// agregamos el valor guardado donde estaba el 3 con el 2
						array[i-1]= aux;
						
						//el resultario seria que primero estaria el 2 y después el 3
						cambios= true;
					}	
				}
				//Cuando ya no entre al for la variable sera false y retornameros el arreglo ordenado acabando el while
				if (cambios == false) {
					break;
				}
			}
		}
	}
}



